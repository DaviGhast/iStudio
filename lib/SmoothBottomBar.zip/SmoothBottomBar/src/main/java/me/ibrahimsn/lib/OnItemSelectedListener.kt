package me.ibrahimsn.lib

interface OnItemSelectedListener {

    fun onItemSelect(pos: Int): Boolean
}
