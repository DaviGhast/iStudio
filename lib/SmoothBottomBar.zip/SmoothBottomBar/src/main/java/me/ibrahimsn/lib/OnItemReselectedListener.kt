package me.ibrahimsn.lib

interface OnItemReselectedListener {

    fun onItemReselect(pos: Int)
}
